package com.solarcleanse.purge

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class Pneeded : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_pneeded)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainPNE)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val backBtn = findViewById<ImageButton>(R.id.btn_back)
        backBtn.setOnClickListener {
            finish() // This will close the current activity and return to the previous one
        }
        val btnRequestQuote = findViewById<View>(R.id.btnRequestQuote)
        btnRequestQuote.setOnClickListener{
            val intent = Intent(this, enhancedt_x::class.java)
            startActivity(intent)
        }
    }
}