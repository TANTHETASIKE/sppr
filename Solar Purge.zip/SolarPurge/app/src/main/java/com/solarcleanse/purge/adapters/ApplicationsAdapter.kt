package com.solarcleanse.purge.adapters

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.solarcleanse.purge.R
import com.solarcleanse.purge.models.ApplicationModel
import com.solarcleanse.purge.detailed_app

class ApplicationsAdapter(
    private var applications: List<ApplicationModel>
) : RecyclerView.Adapter<ApplicationsAdapter.ViewHolder>() {

    inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val appNumber: TextView = itemView.findViewById(R.id.tvAppNumber)
        val appStatus: TextView = itemView.findViewById(R.id.tvAppStatus)
        val appAddress: TextView = itemView.findViewById(R.id.tvAppAddress)
        val appDate: TextView = itemView.findViewById(R.id.tvAppDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_application, parent, false)
        return ViewHolder(v)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val application = applications[position]
        holder.appNumber.text = application.appNumber
        holder.appAddress.text = application.address
        holder.appDate.text = "Submitted: ${application.submittedDate}"
        holder.appStatus.text = application.status
        // Status color logic...

        // Click to open detailed_app
        holder.itemView.setOnClickListener {
            val context = holder.itemView.context
            val intent = Intent(context, detailed_app::class.java)
            intent.putExtra("spiin", application.spiin)
            context.startActivity(intent)
        }
    }

    override fun getItemCount() = applications.size

    fun updateList(newList: List<ApplicationModel>) {
        applications = newList
        notifyDataSetChanged()
    }
}