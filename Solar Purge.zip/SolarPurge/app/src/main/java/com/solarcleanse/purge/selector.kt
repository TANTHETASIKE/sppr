package com.solarcleanse.purge

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class selector : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_selector)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.sImain)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        val solarinstaller = findViewById<View>(R.id.card_install_solar)
        solarinstaller.setOnClickListener {
            val intent = Intent(this, Pneeded::class.java)
            startActivity(intent)
        }

        val sharedPref = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val firstName = sharedPref.getString("first_name", "User") ?: "User"

        val toolbarProfileButton = findViewById<LinearLayout>(R.id.toolbar_profile_button)
        toolbarProfileButton.setOnClickListener {
            val intent = Intent(this, managers::class.java)
            intent.putExtra("first_name", firstName)
            startActivity(intent)
        }

        val toolbarProfileText = findViewById<TextView>(R.id.toolbar_profile_text)
        toolbarProfileText.text = "Hi! $firstName"
    }
}