package com.solarcleanse.purge

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class insptenhance_x : AppCompatActivity() {

    private var backPressedOnce = false
    private val backPressResetDelay: Long = 2000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_insptenhance_x)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.inspector_0)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<ImageButton>(R.id.btn_info).setOnClickListener {
            contactBottomSheet().show(supportFragmentManager, "info_contact-as")
        }

        val spiIn = intent.getStringExtra("spiin") ?: ""
        val name = intent.getStringExtra("name") ?: ""
        val date = intent.getStringExtra("date") ?: ""
        val time = intent.getStringExtra("time") ?: ""

        // Set details in UI
        findViewById<TextView>(R.id.text_name).text = name
        findViewById<TextView>(R.id.text_date).text = date
        findViewById<TextView>(R.id.text_time).text = time
        findViewById<TextView>(R.id.text_id).text = spiIn
        findViewById<TextView>(R.id.text_id_SPiIN).text = spiIn

        // Add to Calendar: stub - implement calendar intent as needed
        findViewById<Button>(R.id.btn_add_calendar).setOnClickListener {
            val title = "Solar Installation Inspection"
            val location = "" // If you have an address, put it here
            val description = "Solar installation inspection scheduled via SolarPurge app."

            // Parse date and time from your variables
            // Example: date = "May 28, 2023", time = "10:30 AM"
            val dateString = "$date $time" // e.g. "May 28, 2023 10:30 AM"
            val format = java.text.SimpleDateFormat("MMM dd, yyyy hh:mm a", java.util.Locale.getDefault())
            val startMillis = try { format.parse(dateString)?.time ?: System.currentTimeMillis() } catch (e: Exception) { System.currentTimeMillis() }
            val endMillis = startMillis + 60 * 60 * 1000 // 1 hour duration

            val intent = Intent(Intent.ACTION_INSERT).apply {
                data = android.provider.CalendarContract.Events.CONTENT_URI
                putExtra(android.provider.CalendarContract.Events.TITLE, title)
                putExtra(android.provider.CalendarContract.Events.EVENT_LOCATION, location)
                putExtra(android.provider.CalendarContract.Events.DESCRIPTION, description)
                putExtra(android.provider.CalendarContract.EXTRA_EVENT_BEGIN_TIME, startMillis)
                putExtra(android.provider.CalendarContract.EXTRA_EVENT_END_TIME, endMillis)
                putExtra(android.provider.CalendarContract.Events.AVAILABILITY, android.provider.CalendarContract.Events.AVAILABILITY_BUSY)
            }
            startActivity(intent)
        }

        // Back to Home
        findViewById<Button>(R.id.tracker).setOnClickListener {
            val intent = Intent(this, applications_managers::class.java)
            startActivity(intent)
            finish()
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        if (backPressedOnce) {
            finishAffinity()
        }
    }
}