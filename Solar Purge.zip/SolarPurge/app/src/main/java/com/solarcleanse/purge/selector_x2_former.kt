package com.solarcleanse.purge

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import com.google.android.material.button.MaterialButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class selector_x2_former : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_selector_x2_former)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainWZR)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        findViewById<ImageButton>(R.id.info_property_type).setOnClickListener {
            InfoPropertyBottomSheet().show(supportFragmentManager, "info_property_type")
        }
        findViewById<ImageButton>(R.id.info_panel_type).setOnClickListener {
            InfoPanelsBottomSheet().show(supportFragmentManager, "info_panel_type")
        }
        findViewById<ImageButton>(R.id.info_sanctioned_load).setOnClickListener {
            InfoSLBottomSheet().show(supportFragmentManager, "info_SL_type")
        }

        val sanctionedLoadEdit = findViewById<EditText>(R.id.input_sanctioned_load)
        val avgBillEdit = findViewById<EditText>(R.id.input_avg_bill)
        val btnNext = findViewById<Button>(R.id.btnNext)
        val backBtn = findViewById<ImageButton>(R.id.btn_back)

        // Panel type buttons
        val btnDcr = findViewById<MaterialButton>(R.id.btn_dcr)
        val btnNonDcr = findViewById<MaterialButton>(R.id.btn_non_dcr)

        // Track which is selected (default DCR)
        var selectedPanelType = ""
        btnDcr.setOnClickListener {
            selectedPanelType = "DCR"
            btnDcr.setStrokeColorResource(R.color.black) // highlight
            btnNonDcr.setStrokeColorResource(R.color.gray) // un-highlight
        }
        btnNonDcr.setOnClickListener {
            selectedPanelType = "Non-DCR"
            btnNonDcr.setStrokeColorResource(R.color.black)
            btnDcr.setStrokeColorResource(R.color.gray)
        }

        backBtn.setOnClickListener {
            finish()
        }

        btnNext.setOnClickListener {
            // Reset errors
            sanctionedLoadEdit.error = null
            avgBillEdit.error = null

            val sanctionedLoadStr = sanctionedLoadEdit.text.toString().trim()
            val avgBillAmountStr = avgBillEdit.text.toString().trim()
            var isValid = true

            if (sanctionedLoadStr.isEmpty()) {
                sanctionedLoadEdit.error = "Required"
                isValid = false
            }
            if (avgBillAmountStr.isEmpty()) {
                avgBillEdit.error = "Required"
                isValid = false
            }

            val userSanctionedLoad = sanctionedLoadStr.toDoubleOrNull()
            val userAvgBillAmount = avgBillAmountStr.toDoubleOrNull()

            if (sanctionedLoadStr.isNotEmpty() && (userSanctionedLoad == null || userSanctionedLoad <= 0.0)) {
                sanctionedLoadEdit.error = "Load cannot be 0"
                isValid = false
            }
            if (avgBillAmountStr.isNotEmpty() && (userAvgBillAmount == null || userAvgBillAmount <= 0.0)) {
                avgBillEdit.error = "Enter a number > 0"
                isValid = false
            }

            if (!isValid) return@setOnClickListener

            val subsidy = calculateSubsidy(userSanctionedLoad ?: 0.0)

            val intent = Intent(this, selector_x2_former_2::class.java)
            intent.putExtra("sanctioned_load", userSanctionedLoad)
            intent.putExtra("avg_bill_amount", userAvgBillAmount)
            intent.putExtra("subsidy", subsidy.toDouble())
            intent.putExtra("panel_type", selectedPanelType)
            startActivity(intent)
        }
    }

    private fun calculateSubsidy(usersanctionedload: Double): Int {
        return when {
            usersanctionedload > 0 && usersanctionedload <= 2 -> {
                (usersanctionedload * 30000).toInt() + 30000
            }
            usersanctionedload > 2 && usersanctionedload <= 3 -> {
                108000
            }
            usersanctionedload > 3 -> {
                108000
            }
            else -> 0
        }
    }
}