package com.solarcleanse.purge

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class enhancedt_xlog : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_enhancedt_xlog)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.enhancedet_xlog)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Show splash for 1500ms, then check login state and navigate
        Handler(Looper.getMainLooper()).postDelayed({
            val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
            val loggedIn = sharedPref.getBoolean("logged_in", false)
            if (loggedIn) {
                val userName = sharedPref.getString("user_name", "") ?: ""
                val intent = Intent(this, selector::class.java)
                intent.putExtra("user_name", userName)
                startActivity(intent)
                finish()
            } else {
                val intent = Intent(this, logsignskip::class.java)
                startActivity(intent)
                finish()
            }
        }, 1500)
    }
}