package com.solarcleanse.purge

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class detailed_app : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detailed_app)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Get values from intent or fallback
        val spiin = intent.getStringExtra("spiin") ?: "#SPIIN9876643467"
        val date = intent.getStringExtra("date") ?: "January 15, 2025"
        val location = intent.getStringExtra("location") ?: "172, Southampton, India"
        val status = intent.getStringExtra("status") ?: "Inspection Requested"
        val inspectorName = intent.getStringExtra("inspectorName") ?: ""
        val inspectorPhone = intent.getStringExtra("inspectorPhone") ?: ""

        // Set toolbar back button
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { onBackPressed() }

        // Set Inspection ID, Date, Location
        findViewById<TextView>(R.id.tvInspectionId).text = spiin
        findViewById<TextView>(R.id.tvDateRequested).text = date
        findViewById<TextView>(R.id.tvLocation).text = location

        // Inspector Info and Call Card (use explicit IDs)
        val inspectorInfoRow = findViewById<LinearLayout>(R.id.inspectorInfoRow)
        val inspectorCallCard = findViewById<LinearLayout>(R.id.inspectorCallCard)

        // Only show Inspector details if inspectorName and inspectorPhone are not blank
        val showInspector = inspectorName.isNotBlank() && inspectorPhone.isNotBlank()
        if (showInspector) {
            findViewById<TextView>(R.id.tvInspector).text = inspectorName
            findViewById<TextView>(R.id.tvInspectorPhone).text = inspectorPhone
            inspectorInfoRow.visibility = View.VISIBLE
            inspectorCallCard.visibility = View.VISIBLE
        } else {
            inspectorInfoRow.visibility = View.GONE
            inspectorCallCard.visibility = View.GONE
        }

        // TIMELINE: Only first step active
        findViewById<ImageView>(R.id.step1_dot).setImageResource(R.drawable.bg_green_dot)
        findViewById<View>(R.id.step2_dot).background = getDrawable(R.drawable.bg_gray_dot)
        findViewById<View>(R.id.step3_dot).background = getDrawable(R.drawable.bg_gray_dot)
        // Hide Timeline Event 2 and 3
        val timeline = findViewById<LinearLayout>(R.id.timelineContainer)
        if (timeline.childCount > 1) timeline.getChildAt(1).visibility = View.GONE
        if (timeline.childCount > 2) timeline.getChildAt(2).visibility = View.GONE

        // "View Full Report" button only visible when status is "Inspection Completed"
        val btnViewFullReport = findViewById<Button>(R.id.btnViewFullReport)
        btnViewFullReport.visibility = if (status == "Inspection Completed") View.VISIBLE else View.GONE
    }
}