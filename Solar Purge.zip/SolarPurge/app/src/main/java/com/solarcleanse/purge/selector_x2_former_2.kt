package com.solarcleanse.purge

import android.animation.Animator
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.*

class selector_x2_former_2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_selector_x2_former2)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // --- Inputs from previous screen ---
        val sanctionedLoad = intent.getDoubleExtra("sanctioned_load", 5.0)
        val avgMonthlyBill = intent.getDoubleExtra("avg_bill_amount", 7500.0)
        val subsidy = intent.getDoubleExtra("subsidy", 108000.0).toInt()
        val selectedPanelType = intent.getStringExtra("panel_type") ?: "DCR"
        val quoteDate = intent.getLongExtra("quote_date", System.currentTimeMillis())
        val quoteNumber = intent.getStringExtra("quote_number") ?: "SPQIN645545"

        // --- Calculations ---
        val payableAmount = if (selectedPanelType == "Non-DCR") {
            sanctionedLoad * 50000
        } else {
            sanctionedLoad * 60000
        }
        val currentBill = avgMonthlyBill
        val currentBillUnits = (avgMonthlyBill - (82.5 * sanctionedLoad)) / 7.5
        val monthlyProduction = 5.45 * sanctionedLoad * 30
        val postSolarBillUnits = currentBillUnits - monthlyProduction
        val postSolarBill = (postSolarBillUnits * 7.5) + (82.5 * sanctionedLoad)
        val roofArea = calculateRoofArea(sanctionedLoad)
        val numPanels = Math.ceil(sanctionedLoad / 0.55).toInt()

        // --- Set Display Values ---
        findViewById<TextView>(R.id.tvQuoteAmount).text =
            "₹" + String.format("%,d", payableAmount.toInt())
        findViewById<TextView>(R.id.tvEstimatedSavings).text =
            "Estimated savings: ₹${String.format("%,.0f", (currentBill - postSolarBill) * 12)}/year"
        findViewById<TextView>(R.id.tvRoofArea).text = "${roofArea} sq. ft."
        findViewById<TextView>(R.id.tvSystemInfo).text = "${sanctionedLoad} kW Solar System"
        findViewById<TextView>(R.id.tvTaxIncentive).text = "-₹" + String.format("%,d", subsidy)
        findViewById<TextView>(R.id.tvNumPanels).text = "Number of Panels: $numPanels"
        findViewById<TextView>(R.id.tvPanelType).text = "Panel Type: $selectedPanelType"

        // Date format e.g. January 23, 2025
        val dateFormat = SimpleDateFormat("MMMM dd, yyyy", Locale.getDefault())
        findViewById<TextView>(R.id.tvQuoteDate).text = dateFormat.format(Date(quoteDate))
        findViewById<TextView>(R.id.tvQuoteNumber).text = "Quote #$quoteNumber"

        // --- Dropdown for Estimated Savings ---
        val estimatedSavingsRow = findViewById<LinearLayout>(R.id.estimatedSavingsRow)
        val arrow = findViewById<ImageView>(R.id.ivSavingsArrow)
        val detailsLayout = findViewById<LinearLayout>(R.id.estimatedSavingsDetails)
        var isDropdownOpen = false

        estimatedSavingsRow.setOnClickListener {
            isDropdownOpen = !isDropdownOpen
            if (isDropdownOpen) {
                expand(detailsLayout)
                ObjectAnimator.ofFloat(arrow, "rotation", 0f, 90f).start()
            } else {
                collapse(detailsLayout)
                ObjectAnimator.ofFloat(arrow, "rotation", 90f, 0f).start()
            }
        }
        // Set details
        findViewById<TextView>(R.id.tvCurrentBill).text =
            "Current Bill: ₹${String.format("%,.0f", currentBill)}"
        findViewById<TextView>(R.id.tvCurrentBillUnits).text =
            "Current Bill Units: ${String.format("%.1f", currentBillUnits)} kWh"
        findViewById<TextView>(R.id.tvMonthlyProduction).text =
            "Monthly Production: ${String.format("%.1f", monthlyProduction)} kWh"
        findViewById<TextView>(R.id.tvPostSolarBillUnits).text =
            "Post-solar Bill Units: ${String.format("%.1f", postSolarBillUnits)} kWh"
        findViewById<TextView>(R.id.tvPostSolarBill).text =
            "Post-solar Bill: ₹${String.format("%,.2f", postSolarBill)}"

        // --- Toolbar back button ---
        findViewById<ImageButton>(R.id.btn_back).setOnClickListener { finish() }

        findViewById<Button>(R.id.btnDownloadQuote).setOnClickListener {
            // TODO: Implement PDF download logic
        }
        findViewById<Button>(R.id.btnBookInspection).setOnClickListener {
            // TODO: Implement navigation or inspection booking
        }
    }

    private fun calculateRoofArea(sanctionedLoad: Double): Int {
        return (sanctionedLoad * 100).toInt()
    }

    private fun expand(view: View) {
        view.measure(
            View.MeasureSpec.makeMeasureSpec((view.parent as View).width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.UNSPECIFIED
        )
        val targetHeight = view.measuredHeight
        view.layoutParams.height = 0
        view.visibility = View.VISIBLE
        val animator = ValueAnimator.ofInt(0, targetHeight)
        animator.addUpdateListener { valueAnimator ->
            view.layoutParams.height = valueAnimator.animatedValue as Int
            view.requestLayout()
        }
        animator.duration = 300
        animator.start()
    }

    private fun collapse(view: View) {
        val initialHeight = view.measuredHeight
        val animator = ValueAnimator.ofInt(initialHeight, 0)
        animator.addUpdateListener { valueAnimator ->
            view.layoutParams.height = valueAnimator.animatedValue as Int
            view.requestLayout()
        }
        animator.duration = 300
        animator.addListener(object : android.animation.AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                view.visibility = View.GONE
            }
        })
        animator.start()
    }
}