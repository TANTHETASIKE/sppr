package com.solarcleanse.purge

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class LoginBSD(
    private val firstName: String?, // null for new user
    private val onContinue: ((String?) -> Unit)? = null
) : BottomSheetDialogFragment() {

    override fun getTheme(): Int = com.google.android.material.R.style.Theme_Design_BottomSheetDialog

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.login_bsd, container, false)
        val tvGreet = view.findViewById<TextView>(R.id.tvGreet)
        val tvSub = view.findViewById<TextView>(R.id.tvSub)
        val btnContinueSheet = view.findViewById<Button>(R.id.btnContinueSheet)
        val tilNameBsd = view.findViewById<TextInputLayout>(R.id.tilNameBsd)
        val etNameBsd = view.findViewById<TextInputEditText>(R.id.etNameBsd)

        if (firstName.isNullOrBlank()) {
            // New user: ask for name
            tvGreet.text = "Welcome to SolarPurge"
            tvSub.text = "Let's get started"
            tilNameBsd.visibility = View.VISIBLE
            btnContinueSheet.setOnClickListener {
                val enteredName = etNameBsd.text?.toString()?.trim()
                if (enteredName.isNullOrEmpty()) {
                    tilNameBsd.error = "Please enter your name"
                } else {
                    tilNameBsd.error = null
                    onContinue?.invoke(enteredName)
                    dismiss()
                }
            }
        } else {
            // Returning user
            tvGreet.text = "Hi! ${firstName.replaceFirstChar { it.uppercaseChar() }}"
            tvSub.text = "let's continue your solar journey"
            tilNameBsd.visibility = View.GONE
            btnContinueSheet.setOnClickListener {
                onContinue?.invoke(firstName)
                dismiss()
            }
        }
        return view
    }

    override fun onStart() {
        super.onStart()
        dialog?.setCanceledOnTouchOutside(false)
        // This makes the window background (the dim/edge) transparent
        dialog?.window?.setBackgroundDrawableResource(android.R.color.transparent)

        // This makes the bottom sheet view background transparent, so only your card shows
        val bottomSheet = dialog?.findViewById<View>(com.google.android.material.R.id.design_bottom_sheet)
        bottomSheet?.setBackgroundResource(android.R.color.transparent)
    }
}