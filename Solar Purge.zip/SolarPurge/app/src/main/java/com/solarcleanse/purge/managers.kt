package com.solarcleanse.purge

import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.Button
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.animation.doOnEnd
import androidx.core.content.edit
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class managers : AppCompatActivity() {

    private var isSettingsExpanded = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_managers)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.account_root)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val backBtn = findViewById<ImageButton>(R.id.btn_back)
        backBtn.setOnClickListener {
            finish() // This will close the current activity and return to the previous one
        }

        val btnApplications = findViewById<LinearLayout>(R.id.btnApplications)
        val tvActiveApplicationsSubtitle = findViewById<TextView>(R.id.tvActiveApplicationsSubtitle)

        // Dynamic text logic
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val userPhone = prefs.getString("user_phone", null)

        if (userPhone != null) {
            val dbRef = FirebaseDatabase.getInstance().reference
            dbRef.child("spiins")
                .orderByChild("inspection_details/phone")
                .equalTo(userPhone)
                .get()
                .addOnSuccessListener { snapshot ->
                    var activeCount = 0
                    for (spiin in snapshot.children) {
                        val status = spiin.child("status").getValue(String::class.java) ?: "Scheduled"
                        if (status == "Scheduled" || status == "In progress") {
                            activeCount++
                        }
                    }
                    tvActiveApplicationsSubtitle.text = when (activeCount) {
                        0 -> "No Active Applications"
                        1 -> "1 Active Application"
                        else -> "$activeCount Active Applications"
                    }
                }
                .addOnFailureListener {
                    tvActiveApplicationsSubtitle.text = "No Active Applications"
                }
        } else {
            tvActiveApplicationsSubtitle.text = "No Active Applications"
        }

        btnApplications.setOnClickListener {
            val intent = Intent(this, applications_managers::class.java)
            startActivity(intent)
        }

        val firstName = intent.getStringExtra("first_name")
            ?: getSharedPreferences("user_prefs", MODE_PRIVATE).getString("first_name", "User")
        val welcomeBanner = findViewById<TextView>(R.id.welcome_banner)
        welcomeBanner.text = "Welcome! $firstName"

        val cardSettingsContent = findViewById<LinearLayout>(R.id.card_settings_content)
        val panelSettings = findViewById<LinearLayout>(R.id.panel_settings)
        val arrowIcon = findViewById<ImageView>(R.id.ic_settings_arrow)

        // Initially collapsed
        panelSettings.visibility = View.GONE
        panelSettings.layoutParams.height = 0
        arrowIcon.rotation = 0f

        cardSettingsContent.setOnClickListener {
            if (!isSettingsExpanded) {
                expandView(panelSettings)
                arrowIcon.animate().rotation(90f).setDuration(250).start()
            } else {
                collapseView(panelSettings)
                arrowIcon.animate().rotation(0f).setDuration(200).start()
            }
            isSettingsExpanded = !isSettingsExpanded
        }

        val btnLogout = findViewById<LinearLayout>(R.id.btn_logout)
        val btnDeleteAccount = findViewById<LinearLayout>(R.id.btn_delete_account)

        btnLogout.setOnClickListener {
            logoutUser()
        }
        btnDeleteAccount.setOnClickListener {
            showDeleteAccountBottomSheet()
        }
    }

    private fun expandView(v: View) {
        v.measure(
            View.MeasureSpec.makeMeasureSpec((v.parent as View).width, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.UNSPECIFIED
        )
        val targetHeight = v.measuredHeight
        v.layoutParams.height = 0
        v.visibility = View.VISIBLE
        val animator = ValueAnimator.ofInt(0, targetHeight)
        animator.addUpdateListener {
            val value = it.animatedValue as Int
            v.layoutParams.height = value
            v.requestLayout()
        }
        animator.duration = 250
        animator.interpolator = AccelerateDecelerateInterpolator()
        animator.start()
    }

    private fun collapseView(v: View) {
        val initialHeight = v.height
        val animator = ValueAnimator.ofInt(initialHeight, 0)
        animator.addUpdateListener {
            val value = it.animatedValue as Int
            v.layoutParams.height = value
            v.requestLayout()
        }
        animator.duration = 200
        animator.interpolator = AccelerateDecelerateInterpolator()
        animator.doOnEnd {
            v.visibility = View.GONE
        }
        animator.start()
    }

    private fun logoutUser() {
        FirebaseAuth.getInstance().signOut()
        // Clear SharedPreferences
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        prefs.edit().clear().apply()
        // Go to login screen (change to your actual login/main activity)
        val intent = Intent(this, logsignskip::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun showDeleteAccountBottomSheet() {
        val view = layoutInflater.inflate(R.layout.delete_account_bsd, null)
        val sheetDialog = BottomSheetDialog(this)
        sheetDialog.setContentView(view)
        sheetDialog.setCancelable(true)

        val btnDelete = view.findViewById<Button>(R.id.btnConfirmDelete)
        val btnCancel = view.findViewById<Button>(R.id.btnCancelDelete)
        val lottieUnlock = view.findViewById<LottieAnimationView>(R.id.lottieUnlock)

        lottieUnlock?.apply {
            visibility = View.VISIBLE
            playAnimation()
        }

        btnDelete.isEnabled = true
        btnCancel.isEnabled = true

        btnDelete.setOnClickListener {
            btnDelete.isEnabled = false
            btnCancel.isEnabled = false
            lottieUnlock?.apply {
                setMinAndMaxFrame(0, lottieUnlock.maxFrame.toInt())
                repeatCount = 0
                playAnimation()
            }
            deleteAccount {
                sheetDialog.dismiss()
            }
        }

        btnCancel.setOnClickListener {
            sheetDialog.dismiss()
        }

        sheetDialog.show()
    }

    private fun deleteAccount(onFinish: (() -> Unit)? = null) {
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val phone = prefs.getString("user_phone", null) ?: run {
            Toast.makeText(this, "Error: Account info not found.", Toast.LENGTH_SHORT).show()
            onFinish?.invoke()
            return
        }
        val user = FirebaseAuth.getInstance().currentUser
        val dbRef = FirebaseDatabase.getInstance().reference

        // 1. Delete people/{phone}
        val peopleDelete = dbRef.child("people").child(phone).removeValue()

        // 2. Find and delete all spiins belonging to this phone
        val spiinsQuery = dbRef.child("spiins").orderByChild("inspection_details/phone").equalTo(phone)
        spiinsQuery.get().addOnSuccessListener { snapshot ->
            val deleteTasks = mutableListOf<com.google.android.gms.tasks.Task<Void>>()
            for (spiinSnap in snapshot.children) {
                deleteTasks.add(spiinSnap.ref.removeValue())
            }
            // Wait for all deletes (if any) to finish before deleting auth
            com.google.android.gms.tasks.Tasks.whenAllComplete(deleteTasks + peopleDelete)
                .addOnSuccessListener {
                    // Now delete Auth account!
                    user?.delete()?.addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            prefs.edit { clear() }
                            val intent = Intent(this, logsignskip::class.java)
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            startActivity(intent)
                            finish()
                            Toast.makeText(this, "Account deleted.", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this, "Failed to delete auth account.", Toast.LENGTH_SHORT).show()
                        }
                        onFinish?.invoke()
                    }
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Failed to delete all user data.", Toast.LENGTH_SHORT).show()
                    onFinish?.invoke()
                }
        }.addOnFailureListener { ex ->
            Toast.makeText(this, "Failed to access spiins: ${ex.message}", Toast.LENGTH_SHORT).show()
            onFinish?.invoke()
        }
    }
}