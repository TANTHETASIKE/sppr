package com.solarcleanse.purge

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Looper
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

class LocIdentifer : AppCompatActivity() {

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var btnCheckLocation: Button

    // REPLACE with your Google Maps Geocoding API key
    private val GOOGLE_API_KEY = "AIzaSyC8_Pinv_Rf_X3liSm_KzbTEnHNQGQNYUw"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_loc_identifer)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        btnCheckLocation = findViewById(R.id.btnCheckLocation)

        btnCheckLocation.setOnClickListener {
            checkLocationPermissionAndFetch()
        }
    }

    private fun checkLocationPermissionAndFetch() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            fetchLocation()
        }
    }

    private fun fetchLocation() {
        if (ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            Toast.makeText(this, "Location required.", Toast.LENGTH_SHORT).show()
            return
        }

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                if (location != null) {
                    checkIfInKanpur(location)
                } else {
                    // Request a fresh update if lastLocation is null
                    val locationRequest = LocationRequest.Builder(
                        Priority.PRIORITY_HIGH_ACCURACY, 0
                    ).setMaxUpdates(1).build()
                    fusedLocationClient.requestLocationUpdates(
                        locationRequest,
                        object : LocationCallback() {
                            override fun onLocationResult(result: LocationResult) {
                                val freshLocation = result.lastLocation
                                if (freshLocation != null) {
                                    checkIfInKanpur(freshLocation)
                                } else {
                                    Toast.makeText(
                                        this@LocIdentifer,
                                        "Couldn't get your location. Try again.",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                                fusedLocationClient.removeLocationUpdates(this)
                            }
                        },
                        Looper.getMainLooper()
                    )
                }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Location error. Try again.", Toast.LENGTH_SHORT).show()
            }
    }

    private fun checkIfInKanpur(location: Location) {
        getCityNameFromLatLng(
            latitude = location.latitude,
            longitude = location.longitude,
            apiKey = GOOGLE_API_KEY
        ) { city ->
            if (city != null && city.equals("Kanpur", ignoreCase = true)) {
                // User is in Kanpur, allow: go to login/signup/skip screen
                startActivity(Intent(this, enhancedet::class.java))
                finish()
            } else {
                // Not in Kanpur: go to unserviceable screen, no toast
                startActivity(Intent(this, unserveskip::class.java))
                finish()
            }
        }
    }

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                fetchLocation()
            } else {
                Toast.makeText(this, "Location required.", Toast.LENGTH_SHORT).show()
            }
        }

    private fun getCityNameFromLatLng(
        latitude: Double,
        longitude: Double,
        apiKey: String,
        onResult: (String?) -> Unit
    ) {
        val url = "https://maps.googleapis.com/maps/api/geocode/json?latlng=$latitude,$longitude&key=$apiKey"
        Thread {
            var cityName: String? = null
            try {
                val client = OkHttpClient()
                val request = Request.Builder().url(url).build()
                val response = client.newCall(request).execute()
                val json = JSONObject(response.body?.string() ?: "")
                val results = json.getJSONArray("results")
                if (results.length() > 0) {
                    val addressComponents = results.getJSONObject(0).getJSONArray("address_components")
                    for (i in 0 until addressComponents.length()) {
                        val component = addressComponents.getJSONObject(i)
                        val types = component.getJSONArray("types")
                        for (j in 0 until types.length()) {
                            val type = types.getString(j)
                            if (type == "locality" || type == "administrative_area_level_2") {
                                cityName = component.getString("long_name")
                                break
                            }
                        }
                        if (cityName != null) break
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
            runOnUiThread {
                onResult(cityName)
            }
        }.start()
    }
}