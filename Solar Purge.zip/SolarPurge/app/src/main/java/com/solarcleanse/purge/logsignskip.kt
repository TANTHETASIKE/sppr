package com.solarcleanse.purge

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.CountDownTimer
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.toColorInt
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.airbnb.lottie.LottieAnimationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import com.google.firebase.database.FirebaseDatabase
import java.util.concurrent.TimeUnit

class logsignskip : AppCompatActivity() {

    private lateinit var etName: EditText
    private lateinit var tilName: TextInputLayout
    private lateinit var etPhone: EditText
    private lateinit var tilPhone: TextInputLayout
    private lateinit var btnContinue: MaterialButton
    private lateinit var complianceText: View
    private lateinit var otpDivider: View
    private lateinit var phoneInputBlock: FrameLayout
    private lateinit var otpInputBlock: LinearLayout
    private lateinit var tvResendOtp: TextView
    private lateinit var tvChangeNumber: TextView
    private lateinit var preloaderOverlay: View
    private lateinit var phoneCheckmark: ImageView
    private lateinit var tvHeading: TextView
    private lateinit var tvOtpSentTo: TextView

    // OTP boxes
    private lateinit var otpBoxes: Array<EditText>

    private lateinit var verificationId: String
    private var resendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var resendTimer: CountDownTimer? = null

    // State variables for login/signup flow
    private var mode = Mode.PHONE
    private var existingUserName: String? = null
    private var isExistingUser: Boolean = false
    private var pendingPhone: String = ""

    // OTP ignore flag to prevent unwanted auto-verification after "Change Phone Number"
    private var ignoreOtpCallbacks = false

    enum class Mode { PHONE, OTP, NAME }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_logsignskip)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.crtlog)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        window.statusBarColor = "#dfeaed".toColorInt()

        fun hideKeyboard(view: View) {
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(view.windowToken, 0)
        }

        etName = findViewById(R.id.etName)
        tilName = findViewById(R.id.tilName)
        etPhone = findViewById(R.id.etPhone)
        tilPhone = findViewById(R.id.tilPhone)
        btnContinue = findViewById(R.id.btnContinue)
        complianceText = findViewById(R.id.tvConsent)
        otpDivider = findViewById(R.id.otpDivider)
        phoneInputBlock = findViewById(R.id.phoneInputBlock)
        otpInputBlock = findViewById(R.id.otpInputBlock)
        tvResendOtp = findViewById(R.id.tvResendOtp)
        tvChangeNumber = findViewById(R.id.tvChangeNumber)
        preloaderOverlay = findViewById(R.id.preloaderOverlay)
        phoneCheckmark = findViewById(R.id.phoneCheckmark)
        tvHeading = findViewById(R.id.tvHeading)
        tvOtpSentTo = findViewById(R.id.tvOtpSentTo)

        // OTP boxes setup
        otpBoxes = arrayOf(
            findViewById(R.id.etOtp1), findViewById(R.id.etOtp2), findViewById(R.id.etOtp3),
            findViewById(R.id.etOtp4), findViewById(R.id.etOtp5), findViewById(R.id.etOtp6)
        )
        setupOtpBoxes()

        // Initially show only phone field and heading
        tilName.visibility = View.GONE
        tvHeading.text = "Login/Signup"
        phoneInputBlock.visibility = View.VISIBLE
        otpInputBlock.visibility = View.GONE

        etName.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                tilName.error = null
                updateContinueState()
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        etPhone.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                tilPhone.error = null
                updateContinueState()
                phoneCheckmark.visibility = View.GONE
            }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        btnContinue.setOnClickListener {
            when (mode) {
                Mode.PHONE -> {
                    val phone = etPhone.text.toString().trim()
                    if (phone.length != 10) {
                        tilPhone.error = "Enter valid phone number"
                        shakeView(tilPhone)
                        return@setOnClickListener
                    }
                    pendingPhone = phone
                    showPreloader()
                    ignoreOtpCallbacks = false
                    sendOtp("+91$phone", isResend = false)
                    etPhone.isEnabled = false
                    tilPhone.isEnabled = false
                    btnContinue.isEnabled = false
                }
                Mode.OTP -> {
                    val otp = otpBoxes.joinToString("") { it.text.toString() }
                    if (otp.length == 6) {
                        showPreloader()
                        verifyOtp(otp)
                    } else {
                        Toast.makeText(this, "Enter valid OTP", Toast.LENGTH_SHORT).show()
                        shakeView(otpInputBlock)
                    }
                }
                Mode.NAME -> {
                    val name = etName.text.toString().trim()
                    if (name.isEmpty()) {
                        tilName.error = "Enter your name"
                        shakeView(tilName)
                        return@setOnClickListener
                    }
                    val phone = pendingPhone
                    showPreloader()
                    createUserAndShowSuccessRDB(name, phone)
                }
            }
        }

        setupOtpActions()
        updateContinueState()
    }

    private fun setupOtpBoxes() {
        for (i in otpBoxes.indices) {
            otpBoxes[i].setOnFocusChangeListener { v, hasFocus ->
                v.setBackgroundResource(if (hasFocus) R.drawable.bg_otp_box_focused else R.drawable.bg_otp_box)
            }
            otpBoxes[i].addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) {
                    if (s?.isNotEmpty() == true && i < otpBoxes.size - 1) {
                        otpBoxes[i + 1].requestFocus()
                    }
                }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }
    }

    private fun sendOtp(phoneNumber: String, isResend: Boolean = false) {
        ignoreOtpCallbacks = false
        showOtpSection()
        val builder = PhoneAuthOptions.newBuilder(FirebaseAuth.getInstance())
            .setPhoneNumber(phoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    if (ignoreOtpCallbacks) return
                    hidePreloader()
                    // NO auto-fill for OTP, as per requirements
                }
                override fun onVerificationFailed(e: FirebaseException) {
                    if (ignoreOtpCallbacks) return
                    hidePreloader()
                    Toast.makeText(
                        this@logsignskip,
                        "Verification failed: ${e.message}",
                        Toast.LENGTH_LONG
                    ).show()
                    etPhone.isEnabled = true
                    tilPhone.isEnabled = true
                    btnContinue.isEnabled = true
                    hideOtpSection()
                    mode = Mode.PHONE
                    btnContinue.text = "CONTINUE"
                    btnContinue.visibility = View.VISIBLE
                    phoneCheckmark.visibility = View.GONE
                }
                override fun onCodeSent(vid: String, token: PhoneAuthProvider.ForceResendingToken) {
                    if (ignoreOtpCallbacks) return
                    hidePreloader()
                    verificationId = vid
                    resendToken = token
                    btnContinue.text = "CONTINUE"
                    btnContinue.isEnabled = true
                    mode = Mode.OTP
                    // Show OTP sent
                    tvOtpSentTo.text = "OTP sent to +91 $pendingPhone"
                }
            })
        if (isResend && resendToken != null) {
            builder.setForceResendingToken(resendToken!!)
        }
        PhoneAuthProvider.verifyPhoneNumber(builder.build())
        startResendOtpTimer()
    }

    private fun verifyOtp(otp: String) {
        val credential = PhoneAuthProvider.getCredential(verificationId, otp)
        signInWithCredential(credential)
    }

    private fun signInWithCredential(credential: PhoneAuthCredential) {
        if (ignoreOtpCallbacks) return
        FirebaseAuth.getInstance().signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                hidePreloader()
                if (task.isSuccessful) {
                    val phone = pendingPhone
                    val db = FirebaseDatabase.getInstance().reference
                    db.child("people").child(phone).get().addOnSuccessListener { snapshot ->
                        if (snapshot.exists()) {
                            isExistingUser = true
                            existingUserName = snapshot.child("name").getValue(String::class.java) ?: ""
                            tvHeading.text = "Login"
                            saveLoginData(existingUserName ?: "", phone)
                            showLoginBSD(existingUserName ?: "")
                        } else {
                            isExistingUser = false
                            tvHeading.text = "Signup"
                            tilName.visibility = View.VISIBLE
                            etName.isEnabled = true
                            tilName.isEnabled = true
                            mode = Mode.NAME
                            btnContinue.text = "REGISTER & CONTINUE"
                            btnContinue.visibility = View.VISIBLE
                            phoneCheckmark.visibility = View.GONE
                            hideOtpSection()
                        }
                    }.addOnFailureListener {
                        Toast.makeText(this, "Network error", Toast.LENGTH_SHORT).show()
                        mode = Mode.PHONE
                        tilName.visibility = View.GONE
                        btnContinue.text = "CONTINUE"
                        btnContinue.visibility = View.VISIBLE
                        etPhone.isEnabled = true
                        tilPhone.isEnabled = true
                    }
                } else {
                    Toast.makeText(this, "Invalid OTP", Toast.LENGTH_SHORT).show()
                    btnContinue.visibility = View.VISIBLE
                    phoneCheckmark.visibility = View.GONE
                }
            }
    }

    private fun showOtpSection() {
        otpDivider.visibility = View.VISIBLE
        phoneInputBlock.visibility = View.GONE
        otpInputBlock.visibility = View.VISIBLE
        // Clear OTP boxes
        otpBoxes.forEach { it.setText("") }
        otpBoxes[0].requestFocus()
        mode = Mode.OTP
        btnContinue.text = "CONTINUE"
        btnContinue.visibility = View.VISIBLE
        phoneCheckmark.visibility = View.GONE
        tvOtpSentTo.text = "OTP sent to +91 $pendingPhone"
    }

    private fun hideOtpSection() {
        otpDivider.visibility = View.GONE
        phoneInputBlock.visibility = View.VISIBLE
        otpInputBlock.visibility = View.GONE
        // Clear OTP boxes
        otpBoxes.forEach { it.setText("") }
        btnContinue.visibility = View.VISIBLE
        phoneCheckmark.visibility = View.GONE
    }

    private fun startResendOtpTimer() {
        tvResendOtp.isEnabled = false
        tvResendOtp.setTextColor(Color.GRAY)
        resendTimer?.cancel()
        val totalMillis = 30_000L
        resendTimer = object : CountDownTimer(totalMillis, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                val seconds = millisUntilFinished / 1000
                tvResendOtp.text = "Resend OTP in 00:%02d".format(seconds)
            }
            override fun onFinish() {
                tvResendOtp.isEnabled = true
                tvResendOtp.setTextColor(Color.BLACK)
                tvResendOtp.text = "Resend OTP"
            }
        }.start()
    }

    private fun setupOtpActions() {
        tvResendOtp.setOnClickListener {
            val phone = etPhone.text.toString().trim()
            if (phone.length == 10) {
                showPreloader()
                sendOtp("+91$phone", isResend = true)
            }
        }
        tvChangeNumber.setOnClickListener {
            ignoreOtpCallbacks = true
            hideOtpSection()
            etPhone.isEnabled = true
            tilPhone.isEnabled = true
            tilName.visibility = View.GONE
            etName.setText("")
            etName.isEnabled = true
            tilName.isEnabled = true
            mode = Mode.PHONE
            btnContinue.text = "CONTINUE"
            btnContinue.visibility = View.VISIBLE
            phoneCheckmark.visibility = View.GONE
            updateContinueState()
            tvHeading.text = "Login/Signup"
        }
    }

    private fun updateContinueState() {
        val phoneOk = etPhone.text?.length == 10
        val nameNotEmpty = etName.text?.isNotBlank() == true
        btnContinue.isEnabled = when (mode) {
            Mode.PHONE -> phoneOk
            Mode.OTP -> true
            Mode.NAME -> nameNotEmpty
        }
        btnContinue.backgroundTintList =
            if (btnContinue.isEnabled) getColorStateList(R.color.black)
            else getColorStateList(android.R.color.darker_gray)
    }

    private fun showPreloader() {
        preloaderOverlay.visibility = View.VISIBLE
    }

    private fun hidePreloader() {
        preloaderOverlay.visibility = View.GONE
    }

    private fun shakeView(view: View) {
        view.animate()
            .translationX(12f).setDuration(50).withEndAction {
                view.animate().translationX(-12f).setDuration(50).withEndAction {
                    view.animate().translationX(0f).setDuration(50).start()
                }.start()
            }.start()
    }

    override fun onDestroy() {
        super.onDestroy()
        resendTimer?.cancel()
    }

    private fun createUserAndShowSuccessRDB(name: String, phone: String) {
        val db = FirebaseDatabase.getInstance().reference
        val user = mapOf(
            "name" to name,
            "phone" to phone,
            "created_at" to System.currentTimeMillis()
        )
        db.child("people").child(phone).setValue(user)
            .addOnSuccessListener {
                saveLoginData(name, phone)
                showLoginBSD(name)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Saved locally. (Cloud error)", Toast.LENGTH_SHORT).show()
                saveLoginData(name, phone)
                showLoginBSD(name)
            }
    }

    private fun showLoginBSD(fullName: String) {
        // Use the new modern LoginBSD bottom sheet fragment
        val firstWord = fullName.trim().split(" ").firstOrNull()?.replaceFirstChar { it.uppercaseChar() } ?: ""
        LoginBSD(firstName = firstWord) {
            val intent = Intent(this, selector::class.java)
            intent.putExtra("user_name", firstWord)
            startActivity(intent)
            finish()
        }.show(supportFragmentManager, "LoginBSD")
    }

    private fun saveLoginData(name: String, phone: String) {
        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val firstName = name.trim().split(" ").firstOrNull()?.replaceFirstChar { it.uppercaseChar() } ?: "User"
        sharedPref.edit().apply {
            putBoolean("logged_in", true)
            putString("user_name", name)
            putString("user_phone", phone)
            putString("first_name", firstName)
            apply()
        }
    }
}