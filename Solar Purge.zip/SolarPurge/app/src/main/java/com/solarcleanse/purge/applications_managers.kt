package com.solarcleanse.purge

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.solarcleanse.purge.adapters.ApplicationsAdapter
import com.solarcleanse.purge.models.ApplicationModel

class applications_managers : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyStateLayout: LinearLayout
    private lateinit var searchL: LinearLayout
    private lateinit var btn_new_inspection: Button
    private lateinit var adapter: ApplicationsAdapter
    private lateinit var searchEditText: EditText

    private var applications: List<ApplicationModel> = listOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_applications_managers)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main_root_layout)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val backBtn = findViewById<ImageButton>(R.id.btn_back)
        backBtn.setOnClickListener {
            finish() // This will close the current activity and return to the previous one
        }

        recyclerView = findViewById(R.id.recycler_applications)
        emptyStateLayout = findViewById(R.id.empty_state_layout)
        btn_new_inspection = findViewById(R.id.btn_new_inspection)
        searchEditText = findViewById(R.id.search_applications)
        searchL = findViewById(R.id.searchL)

        adapter = ApplicationsAdapter(applications)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter

        // Fetch SPIIN applications from Firebase for this user
        fetchApplicationsFromFirebase()

        btn_new_inspection.setOnClickListener {
            val intent = Intent(this, enhance_inspect::class.java)
            startActivity(intent)
        }

        // Optional: Add search/filter functionality
        searchEditText.setOnEditorActionListener { v, actionId, event ->
            val query = searchEditText.text.toString().trim()
            filterApplications(query)
            true
        }
    }

    private fun fetchApplicationsFromFirebase() {
        val prefs = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val userPhone = prefs.getString("user_phone", null)
        if (userPhone == null) {
            // Handle missing phone number (show empty state)
            applications = emptyList()
            adapter.updateList(applications)
            updateUI()
            return
        }

        val dbRef = FirebaseDatabase.getInstance().reference
        dbRef.child("spiins")
            .orderByChild("inspection_details/phone")
            .equalTo(userPhone)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val appList = mutableListOf<ApplicationModel>()
                    for (spiinSnap in snapshot.children) {
                        val appNumber = spiinSnap.key ?: ""
                        val details = spiinSnap.child("inspection_details")
                        val address = details.child("address").getValue(String::class.java) ?: ""
                        val submittedDate = details.child("date").getValue(String::class.java) ?: ""
                        val status = spiinSnap.child("status").getValue(String::class.java) ?: "Scheduled"

                        appList.add(
                            ApplicationModel(
                                appNumber = "#$appNumber",
                                address = address,
                                submittedDate = submittedDate,
                                status = status
                            )
                        )
                    }
                    applications = appList
                    adapter.updateList(applications)
                    updateUI()
                }

                override fun onCancelled(error: DatabaseError) {
                    // Handle error (show empty state or toast)
                    applications = emptyList()
                    adapter.updateList(applications)
                    updateUI()
                }
            })
    }

    private fun updateUI() {
        if (applications.isEmpty()) {
            recyclerView.visibility = View.GONE
            emptyStateLayout.visibility = View.VISIBLE
            btn_new_inspection.visibility = View.VISIBLE
            searchL.visibility = View.GONE
            // Set background to whitish-grey
            findViewById<View>(R.id.main_root_layout).setBackgroundColor(0xFFF7F7F7.toInt())
        } else {
            recyclerView.visibility = View.VISIBLE
            emptyStateLayout.visibility = View.GONE
            btn_new_inspection.visibility = View.GONE
            searchL.visibility = View.VISIBLE
            // Set background to white
            findViewById<View>(R.id.main_root_layout).setBackgroundColor(0xFFFFFFFF.toInt())
        }
    }

    private fun filterApplications(query: String) {
        val filtered = applications.filter {
            it.appNumber.contains(query, ignoreCase = true) ||
                    it.address.contains(query, ignoreCase = true) ||
                    it.status.contains(query, ignoreCase = true)
        }
        adapter.updateList(filtered)
    }
}