package com.solarcleanse.purge

import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class unserveskip : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_unserveskip)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.dontserver)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Optional: Set status bar to white
        window.statusBarColor = getColor(android.R.color.white)

        val btnClose = findViewById<Button>(R.id.btnClose)

        btnClose.setOnClickListener { finishAffinity() }

    }
}