package com.solarcleanse.purge.models

data class ApplicationModel(
    val spiin: String = "",
    val appNumber: String = "",
    val address: String = "",
    val submittedDate: String = "",
    val status: String = "Scheduled" // Default/initial status
)