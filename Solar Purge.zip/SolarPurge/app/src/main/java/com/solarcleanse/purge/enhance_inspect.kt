package com.solarcleanse.purge

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class enhance_inspect : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_enhance_inspect)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.enhanc_inspect)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Show for 2-4 seconds, then go to selector screen
        Handler(Looper.getMainLooper()).postDelayed({
            startActivity(Intent(this, selector_x2_former::class.java))
            overridePendingTransition(R.anim.fade_in, R.anim.fade_out)
            finish()
        }, 1400) // 1500-2500 seconds.
    }
}