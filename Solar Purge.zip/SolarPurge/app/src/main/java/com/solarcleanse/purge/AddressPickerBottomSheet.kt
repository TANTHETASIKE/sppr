package com.solarcleanse.purge

import android.Manifest
import android.app.Dialog
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import java.util.*

class AddressPickerBottomSheet(
    val onAddressSelected: (lat: Double, lng: Double, address: String) -> Unit
) : BottomSheetDialogFragment(), OnMapReadyCallback {

    private var googleMap: GoogleMap? = null
    private var marker: Marker? = null
    private lateinit var inputSiteAddress: TextInputEditText
    private lateinit var confirmButton: MaterialButton

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_address_picker, container, false)
        inputSiteAddress = view.findViewById(R.id.input_site_address)
        confirmButton = view.findViewById(R.id.btn_confirm_address)

        val mapFragment = SupportMapFragment.newInstance()
        childFragmentManager.beginTransaction()
            .replace(R.id.map_container, mapFragment)
            .commitNow()
        mapFragment.getMapAsync(this)

        confirmButton.setOnClickListener {
            val address = inputSiteAddress.text?.toString() ?: ""
            val position = marker?.position
            if (position == null || address.isBlank()) {
                Toast.makeText(requireContext(), "Please select a location.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            onAddressSelected(position.latitude, position.longitude, address)
            dismiss()
        }

        return view
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        // Prevent swipe to dismiss, but allow tap outside to dismiss
        val dialog = super.onCreateDialog(savedInstanceState) as BottomSheetDialog
        dialog.setCanceledOnTouchOutside(true)
        dialog.behavior.isDraggable = false
        return dialog
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        googleMap?.uiSettings?.isZoomControlsEnabled = true

        val fusedLocationClient = LocationServices.getFusedLocationProviderClient(requireActivity())
        if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationClient.lastLocation.addOnSuccessListener { location: Location? ->
                val userLatLng = if (location != null) {
                    LatLng(location.latitude, location.longitude)
                } else {
                    LatLng(28.6139, 77.2090) // Default: New Delhi
                }
                moveMarker(userLatLng)
                googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(userLatLng, 16f))
            }
        } else {
            val defaultLatLng = LatLng(28.6139, 77.2090) // New Delhi
            moveMarker(defaultLatLng)
            googleMap?.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLatLng, 14f))
        }

        googleMap?.setOnMapClickListener { latLng ->
            moveMarker(latLng)
        }
        googleMap?.setOnMarkerDragListener(object : GoogleMap.OnMarkerDragListener {
            override fun onMarkerDragStart(p0: Marker) {}
            override fun onMarkerDrag(p0: Marker) {}
            override fun onMarkerDragEnd(marker: Marker) {
                moveMarker(marker.position)
            }
        })
    }

    private fun moveMarker(latLng: LatLng) {
        if (marker == null) {
            marker = googleMap?.addMarker(
                MarkerOptions().position(latLng).draggable(true).title("Selected Location")
            )
        } else {
            marker?.position = latLng
        }
        // Reverse geocode
        val geocoder = Geocoder(requireContext(), Locale.getDefault())
        Thread {
            try {
                val results = geocoder.getFromLocation(latLng.latitude, latLng.longitude, 1)
                val addressLine = results?.firstOrNull()?.getAddressLine(0)
                requireActivity().runOnUiThread {
                    inputSiteAddress.setText(addressLine ?: "Unknown Location")
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    inputSiteAddress.setText("Unknown Location")
                }
            }
        }.start()
    }
}