package com.solarcleanse.purge

import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.google.firebase.database.FirebaseDatabase
import java.text.SimpleDateFormat
import java.util.*

class selector_x2_former3 : AppCompatActivity() {

    private lateinit var inputName: TextInputEditText
    private lateinit var inputPhone: TextInputEditText
    private lateinit var addressLayout: TextInputLayout
    private lateinit var inputAddress: TextInputEditText
    private lateinit var btnSchedule: MaterialButton
    private lateinit var dateSpinner: Spinner
    private lateinit var timeSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_selector_x2_former3)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.mainFORMER3)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Initialize fields
        inputName = findViewById(R.id.input_name)
        inputPhone = findViewById(R.id.input_phone)
        inputAddress = findViewById(R.id.input_address)
        addressLayout = findViewById(R.id.address_layout)
        btnSchedule = findViewById(R.id.btnSchedule)
        dateSpinner = findViewById(R.id.date_spinner)
        timeSpinner = findViewById(R.id.time_spinner)

        // Autofill from SharedPreferences (as set during login)
        val sharedPref = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val userName = sharedPref.getString("user_name", "") ?: ""
        val userPhone = sharedPref.getString("user_phone", "") ?: ""
        inputName.setText(userName)
        inputPhone.setText(userPhone)
        inputName.isEnabled = false
        inputPhone.isEnabled = false
        inputName.isFocusable = false
        inputPhone.isFocusable = false

        // Address picker (implement as per your AddressPickerBottomSheet or Google Places logic)
        inputAddress.setOnClickListener {
            // Example: Replace with your own address picker dialog
            val bottomSheet = AddressPickerBottomSheet { lat, lng, address ->
                inputAddress.setText(address)
                // Save lat/lng/address as needed
            }
            bottomSheet.show(supportFragmentManager, "address_picker")
        }

        // --- Populate Date Spinner (Current +1 day to +1 month) ---
        val dateList = mutableListOf<String>()
        val dateFormat = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault())
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1) // Start from tomorrow

        val endCal = Calendar.getInstance()
        endCal.add(Calendar.DAY_OF_YEAR, 1)
        endCal.add(Calendar.MONTH, 1) // Up to one month from tomorrow

        while (!cal.after(endCal)) {
            dateList.add(dateFormat.format(cal.time))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }

        val dateAdapter = ArrayAdapter(
            this,
            R.layout.spinner_item_black,
            dateList
        ).apply {
            setDropDownViewResource(R.layout.spinner_dropdown_item_black)
        }
        dateSpinner.adapter = dateAdapter

        // --- Populate Time Spinner (10:00 AM to 6:00 PM, 15 min intervals) ---
        val timeList = mutableListOf<String>()
        val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
        val timeCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 10)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val endTimeCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 18)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        while (!timeCal.after(endTimeCal)) {
            timeList.add(timeFormat.format(timeCal.time))
            timeCal.add(Calendar.MINUTE, 15)
        }
        val timeAdapter = ArrayAdapter(
            this,
            R.layout.spinner_item_black,
            timeList
        ).apply {
            setDropDownViewResource(R.layout.spinner_dropdown_item_black)
        }
        timeSpinner.adapter = timeAdapter

        btnSchedule.setOnClickListener {
            scheduleInspection()
        }
    }

    private fun scheduleInspection() {
        val name = inputName.text?.toString()?.trim()
        val phone = inputPhone.text?.toString()?.trim()
        val address = inputAddress.text?.toString()?.trim()
        val date = dateSpinner.selectedItem as? String
        val time = timeSpinner.selectedItem as? String

        // Validation
        if (name.isNullOrEmpty()) { inputName.error = "Required"; return }
        if (phone.isNullOrEmpty()) { /* should never happen */ return }
        if (address.isNullOrEmpty()) { addressLayout.error = "Select address from map"; return }
        if (date.isNullOrEmpty()) { Toast.makeText(this, "Select a date", Toast.LENGTH_SHORT).show(); return }
        if (time.isNullOrEmpty()) { Toast.makeText(this, "Select a time", Toast.LENGTH_SHORT).show(); return }

        val spiIn = "SPIIN" + UUID.randomUUID().toString().take(8).uppercase()
        val now = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.getDefault()).format(Date())

        val inspectionData = hashMapOf(
            "spiin" to spiIn,
            "inspection_details" to hashMapOf(
                "name" to name,
                "phone" to phone,
                "address" to address,
                "date" to date,
                "time" to time,
                "status" to "Scheduled"
            ),
            "created_at" to now
        )

        FirebaseDatabase.getInstance().getReference("spiins").child(spiIn)
            .setValue(inspectionData)
            .addOnSuccessListener {
                val intent = Intent(this, insptenhance_x::class.java)
                intent.putExtra("spiin", spiIn)
                intent.putExtra("name", name)
                intent.putExtra("date", date)
                intent.putExtra("time", time)
                startActivity(intent)
                finish()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error scheduling inspection! Try again.", Toast.LENGTH_SHORT).show()
            }
    }
}